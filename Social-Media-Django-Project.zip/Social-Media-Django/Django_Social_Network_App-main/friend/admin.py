from django.contrib import admin
from friend.models import FriendList, FriendRequest

admin.site.register(FriendList)
admin.site.register(FriendRequest)
